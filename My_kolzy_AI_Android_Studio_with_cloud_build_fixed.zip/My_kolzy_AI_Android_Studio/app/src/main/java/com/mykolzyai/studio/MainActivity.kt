package com.mykolzyai.studio

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

private val Ink = Color(0xFF17191F)
private val Panel = Color(0xFF242832)
private val Accent = Color(0xFF8AB4F8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen() {
    val scenes = remember { mutableStateListOf<Uri>() }
    var secondsPerScene by remember { mutableFloatStateOf(6f) }
    var projectName by remember { mutableStateOf("Мой первый ролик") }
    var notice by remember { mutableStateOf("Добавь изображения, чтобы собрать раскадровку.") }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { selected ->
        scenes.addAll(selected)
        notice = if (selected.isEmpty()) "Изображения не выбраны."
                 else "Добавлено изображений: ${selected.size}"
    }

    val totalSeconds = scenes.size * secondsPerScene.toInt()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("My kolzy AI", fontWeight = FontWeight.Bold)
                        Text("Твоя личная видеостудия",
                            style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
                    }
                }, colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Ink, titleContentColor = Color.White
                ))
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Новый видеопроект", style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold)
                            OutlinedTextField(value = projectName, onValueChange = { projectName = it },
                                label = { Text("Название проекта") }, singleLine = true,
                                modifier = Modifier.fillMaxWidth())
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Movie, contentDescription = null, tint = Accent)
                                Spacer(Modifier.width(8.dp))
                                Text("Цель: ролик до 1 минуты", color = Color.White)
                            }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Раскадровка", style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold)
                            Text("Добавь фото — каждое станет отдельной сценой.")
                            Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Добавить изображения")
                            }
                            Text("Длительность одной сцены: ${secondsPerScene.toInt()} сек.")
                            Slider(value = secondsPerScene, onValueChange = { secondsPerScene = it },
                                valueRange = 3f..10f, steps = 6)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Сцен: ${scenes.size}")
                                Text("Примерная длина: ${totalSeconds} сек.",
                                    color = if (totalSeconds > 60) Color(0xFFFFB4AB) else Accent)
                            }
                            if (totalSeconds > 60) Text(
                                "Уменьши число сцен или длительность, чтобы уложиться в минуту.",
                                color = Color(0xFFFFB4AB), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                if (scenes.isEmpty()) {
                    item {
                        Box(Modifier.fillMaxWidth().height(130.dp)
                            .clip(RoundedCornerShape(18.dp)).background(Panel),
                            contentAlignment = Alignment.Center) {
                            Text("Здесь появятся твои сцены", color = Color.LightGray)
                        }
                    }
                } else {
                    itemsIndexed(scenes) { index, uri ->
                        Card(colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(16.dp)) {
                            Row(Modifier.fillMaxWidth().padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(model = uri, contentDescription = "Сцена ${index + 1}",
                                    modifier = Modifier.size(76.dp).clip(RoundedCornerShape(12.dp)),
                                    contentScale = ContentScale.Crop)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Сцена ${index + 1}", fontWeight = FontWeight.SemiBold)
                                    Text("${secondsPerScene.toInt()} секунд", color = Color.LightGray,
                                        style = MaterialTheme.typography.bodySmall)
                                }
                                IconButton(onClick = { scenes.removeAt(index) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Удалить сцену",
                                        tint = Color(0xFFFFB4AB))
                                }
                            }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Следующий этап", style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold)
                            Text("Далее добавим офлайн-озвучку, эффекты движения и экспорт MP4.")
                            Text(notice, color = Accent, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item { Spacer(Modifier.height(20.dp)) }
            }
        }
    }
}
